export interface Token {
  address: string;
  symbol: string;
  name: string;
  decimals: number;
  color: string;
}

// Correct Cronos mainnet addresses (verified against VVS docs)
export const TOKENS: Token[] = [
  {
    address: "0x5C7F8A570d578ED84E63fdFA7b1eE72dEae1AE23",
    symbol: "WCRO",
    name: "Wrapped CRO",
    decimals: 18,
    color: "#1199FA",
  },
  {
    address: "0xc21223249CA28397B4B6541dfFaEEC539BfF0c59",
    symbol: "USDC",
    name: "USD Coin",
    decimals: 6,
    color: "#2775CA",
  },
  {
    address: "0x66e428c3f67a68767596461f7ee3ec71a3a3bab5",
    symbol: "USDT",
    name: "Tether",
    decimals: 6,
    color: "#26A17B",
  },
  {
    address: "0x062E66477Faf610fFaFe27FCADC3c7E6390d4E9c",
    symbol: "WBTC",
    name: "Wrapped Bitcoin",
    decimals: 8,
    color: "#F7931A",
  },
  {
    address: "0xe44Fd7fCb2b1581822D0c862B68222998a0c299a",
    symbol: "WETH",
    name: "Wrapped Ether",
    decimals: 18,
    color: "#627EEA",
  },
  {
    address: "0x2d03bece6747adc00e1a131bba1469c15fd11e03",
    symbol: "VVS",
    name: "VVS Finance",
    decimals: 18,
    color: "#E94560",
  },
  {
    address: "0xdd73dea10abc2bff99c60882ec5b91b0b9849589",
    symbol: "TONIC",
    name: "Tectonic",
    decimals: 18,
    color: "#00D4AA",
  },
];

export const getTokenByAddress = (address: string): Token | undefined => {
  return TOKENS.find((t) => t.address.toLowerCase() === address.toLowerCase());
};

export const getTokenBySymbol = (symbol: string): Token | undefined => {
  return TOKENS.find((t) => t.symbol.toUpperCase() === symbol.toUpperCase());
};
