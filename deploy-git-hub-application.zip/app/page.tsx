"use client"

import { useEffect, useMemo, useState } from "react"
import { ArrowDown, ArrowDownUp, ArrowUpRight, BarChart3, ChevronDown, CircleDollarSign, Fuel, Menu, RefreshCw, Settings2, ShieldCheck, Sparkles, Wallet, X } from "lucide-react"
import { BrowserProvider, Contract, JsonRpcProvider, formatUnits, parseUnits } from "ethers"
import { TOKENS, type Token } from "@/lib/tokens"
import { ACTIVE_CHAIN } from "@/lib/chains"
import { getSwapQuote, approveToken, executeSwap } from "@/lib/swap"

const tabs = ["Overview", "Swap", "Markets", "Portfolio"]
const marketRows = [
  { token: TOKENS[0], price: "$0.0942", change: "+4.82%", volume: "$8.42M", liquidity: "$24.8M", positive: true },
  { token: TOKENS[2], price: "$1.0001", change: "+0.01%", volume: "$5.91M", liquidity: "$18.2M", positive: true },
  { token: TOKENS[1], price: "$0.00084", change: "-2.14%", volume: "$1.24M", liquidity: "$6.7M", positive: false },
  { token: TOKENS[3], price: "$0.9998", change: "-0.03%", volume: "$882K", liquidity: "$11.4M", positive: false },
]

function TokenIcon({ token, size = "md" }: { token: Token; size?: "sm" | "md" | "lg" }) {
  const dimensions = size === "lg" ? "h-12 w-12 text-sm" : size === "sm" ? "h-8 w-8 text-[10px]" : "h-10 w-10 text-xs"
  return <div className={`${dimensions} flex shrink-0 items-center justify-center rounded-full font-bold text-white ring-4 ring-white/5`} style={{ background: token.color }}>{token.symbol.slice(0, 2)}</div>
}

export default function Page() {
  const [activeTab, setActiveTab] = useState("Overview")
  const [account, setAccount] = useState<string | null>(null)
  const [mobileOpen, setMobileOpen] = useState(false)
  const [fromToken, setFromToken] = useState(TOKENS[0])
  const [toToken, setToToken] = useState(TOKENS[2])
  const [fromAmount, setFromAmount] = useState("")
  const [toAmount, setToAmount] = useState("")
  const [quoteLoading, setQuoteLoading] = useState(false)
  const [slippage, setSlippage] = useState("0.5")
  const [message, setMessage] = useState("")
  const [showSettings, setShowSettings] = useState(false)

  useEffect(() => {
    if (!fromAmount || Number(fromAmount) <= 0) { setToAmount(""); return }
    const timer = window.setTimeout(async () => {
      setQuoteLoading(true)
      try {
        const quote = await getSwapQuote(fromToken, toToken, fromAmount, Number(slippage))
        setToAmount(quote.amountOut)
      } catch { setToAmount("") } finally { setQuoteLoading(false) }
    }, 500)
    return () => window.clearTimeout(timer)
  }, [fromAmount, fromToken, toToken, slippage])

  const connectWallet = async () => {
    const ethereum = (window as Window & { ethereum?: unknown }).ethereum as { request: (args: { method: string; params?: unknown[] }) => Promise<string[]> } | undefined
    if (!ethereum) { setMessage("Install a compatible wallet to continue."); return }
    try {
      const accounts = await ethereum.request({ method: "eth_requestAccounts" })
      setAccount(accounts[0])
      setMessage("")
    } catch { setMessage("Wallet connection was cancelled.") }
  }

  const flip = () => { const token = fromToken; setFromToken(toToken); setToToken(token); setFromAmount(toAmount); setToAmount(fromAmount) }
  const execute = async () => {
    if (!account || !fromAmount || !toAmount) { setMessage("Connect your wallet and enter an amount first."); return }
    setMessage("Review the transaction in your wallet.")
  }

  return (
    <main className="min-h-screen overflow-x-hidden bg-[#071018] text-white">
      <div className="pointer-events-none fixed inset-0 bg-[radial-gradient(circle_at_8%_0%,rgba(19,202,175,.13),transparent_32%),radial-gradient(circle_at_90%_20%,rgba(81,93,255,.12),transparent_28%)]" />
      <header className="relative z-20 border-b border-white/[0.07] bg-[#071018]/85 backdrop-blur-xl">
        <div className="mx-auto flex h-[76px] max-w-[1320px] items-center justify-between px-5 lg:px-8">
          <div className="flex items-center gap-9">
            <button className="flex items-center gap-3" onClick={() => setActiveTab("Overview")} aria-label="Go to overview">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-[#2bd7b2] to-[#4c6fff] shadow-[0_0_28px_rgba(43,215,178,.25)]"><Sparkles size={20} /></div>
              <div className="text-left"><div className="text-lg font-black tracking-tight">MERY<span className="text-[#35d9ba]">DEX</span></div><div className="text-[10px] uppercase tracking-[.22em] text-slate-500">Cronos liquidity</div></div>
            </button>
            <nav className="hidden items-center gap-1 md:flex">{tabs.map(tab => <button key={tab} onClick={() => setActiveTab(tab)} className={`rounded-lg px-4 py-2 text-sm font-medium transition ${activeTab === tab ? "bg-white/[0.09] text-white" : "text-slate-400 hover:text-white"}`}>{tab}</button>)}</nav>
          </div>
          <div className="flex items-center gap-3"><div className="hidden items-center gap-2 rounded-full border border-white/10 bg-white/[0.04] px-3 py-2 text-xs text-slate-400 sm:flex"><span className="h-2 w-2 rounded-full bg-[#35d9ba] shadow-[0_0_10px_#35d9ba]" />Cronos Mainnet</div><button onClick={connectWallet} className="rounded-xl bg-[#35d9ba] px-4 py-2.5 text-sm font-bold text-[#061016] transition hover:bg-[#5ce8cd]">{account ? `${account.slice(0, 6)}...${account.slice(-4)}` : "Connect wallet"}</button><button className="rounded-lg p-2 text-slate-400 md:hidden" onClick={() => setMobileOpen(!mobileOpen)} aria-label="Toggle menu"><Menu size={20} /></button></div>
        </div>
        {mobileOpen && <div className="border-t border-white/10 px-5 py-3 md:hidden">{tabs.map(tab => <button key={tab} onClick={() => { setActiveTab(tab); setMobileOpen(false) }} className="mr-2 rounded-lg px-3 py-2 text-sm text-slate-300">{tab}</button>)}</div>}
      </header>

      <div className="relative mx-auto max-w-[1320px] px-5 py-8 lg:px-8 lg:py-12">
        {activeTab === "Swap" ? <SwapPanel {...{ fromToken, toToken, fromAmount, toAmount, quoteLoading, slippage, setFromAmount, setToAmount, setFromToken, setToToken, setSlippage, flip, execute, showSettings, setShowSettings, account }} /> : <>
          <section className="mb-10 flex flex-col justify-between gap-7 lg:flex-row lg:items-end"><div><div className="mb-4 flex items-center gap-2 text-xs font-semibold uppercase tracking-[.2em] text-[#35d9ba]"><span className="h-px w-8 bg-[#35d9ba]" />Cronos ecosystem</div><h1 className="max-w-2xl text-4xl font-black tracking-tight text-balance sm:text-6xl">Trade smarter on <span className="bg-gradient-to-r from-[#35d9ba] to-[#7387ff] bg-clip-text text-transparent">Cronos.</span></h1><p className="mt-5 max-w-xl text-base leading-7 text-slate-400">A faster, cleaner way to swap tokens and discover liquidity across the Cronos network.</p></div><button onClick={() => setActiveTab("Swap")} className="flex w-fit items-center gap-2 rounded-xl bg-white px-5 py-3 text-sm font-bold text-[#071018] transition hover:bg-[#35d9ba]">Start swapping <ArrowUpRight size={17} /></button></section>
          <section className="mb-8 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">{[{ icon: BarChart3, label: "24h volume", value: "$16.45M", change: "+12.8%" }, { icon: CircleDollarSign, label: "Total liquidity", value: "$61.1M", change: "+4.2%" }, { icon: Fuel, label: "Avg. gas fee", value: "$0.04", change: "-18.3%" }, { icon: Wallet, label: "Active wallets", value: "24,892", change: "+8.9%" }].map(({ icon: Icon, label, value, change }) => <div key={label} className="rounded-2xl border border-white/[0.08] bg-white/[0.035] p-5"><div className="flex items-center justify-between text-xs text-slate-500"><span>{label}</span><Icon size={17} className="text-[#35d9ba]" /></div><div className="mt-4 flex items-end justify-between"><strong className="text-2xl font-bold">{value}</strong><span className="text-xs font-semibold text-[#35d9ba]">{change}</span></div></div>)}</section>
          <section className="grid gap-6 lg:grid-cols-[1.45fr_1fr]"><div className="rounded-2xl border border-white/[0.08] bg-white/[0.035] p-5 sm:p-6"><div className="mb-5 flex items-center justify-between"><div><h2 className="font-bold">Market overview</h2><p className="mt-1 text-xs text-slate-500">Top Cronos assets by activity</p></div><button className="rounded-lg border border-white/10 p-2 text-slate-400 hover:text-white" aria-label="Refresh markets"><RefreshCw size={15} /></button></div><div className="overflow-x-auto"><table className="w-full min-w-[590px] text-left text-sm"><thead className="border-b border-white/[0.07] text-xs text-slate-500"><tr><th className="pb-3 font-medium">Asset</th><th className="pb-3 font-medium">Price</th><th className="pb-3 font-medium">24h</th><th className="pb-3 font-medium">Volume</th><th className="pb-3 font-medium">Liquidity</th></tr></thead><tbody>{marketRows.map(row => <tr key={row.token.symbol} className="border-b border-white/[0.05] last:border-0"><td className="py-4"><div className="flex items-center gap-3"><TokenIcon token={row.token} size="sm" /><div><div className="font-semibold">{row.token.symbol}</div><div className="text-xs text-slate-500">{row.token.name}</div></div></div></td><td className="font-medium">{row.price}</td><td className={row.positive ? "text-[#35d9ba]" : "text-[#ff7187]"}>{row.change}</td><td className="text-slate-300">{row.volume}</td><td className="text-slate-300">{row.liquidity}</td></tr>)}</tbody></table></div></div><div className="rounded-2xl border border-white/[0.08] bg-gradient-to-br from-[#102a31] to-[#11192b] p-6"><div className="mb-10 flex items-center justify-between"><div><div className="mb-2 flex items-center gap-2 text-xs font-semibold text-[#35d9ba]"><ShieldCheck size={15} />NON-CUSTODIAL</div><h2 className="text-2xl font-bold">Swap with confidence.</h2></div><ArrowDownUp className="text-[#35d9ba]" size={30} /></div><p className="max-w-sm text-sm leading-6 text-slate-400">Your keys stay in your wallet. Every route is quoted on-chain and protected by your slippage settings.</p><button onClick={() => setActiveTab("Swap")} className="mt-8 flex items-center gap-2 text-sm font-bold text-white hover:text-[#35d9ba]">Open swap <ArrowUpRight size={16} /></button></div></section>
        </>}
      </div>
      <footer className="relative border-t border-white/[0.07] py-6"><div className="mx-auto flex max-w-[1320px] flex-col justify-between gap-3 px-5 text-xs text-slate-500 sm:flex-row lg:px-8"><span>MERYDEX on Cronos Mainnet</span><span>VVS Finance router · Non-custodial trading</span></div></footer>
      {message && <div role="status" className="fixed bottom-5 left-1/2 z-50 flex -translate-x-1/2 items-center gap-3 rounded-xl border border-white/10 bg-[#13212a] px-4 py-3 text-sm shadow-2xl"><span>{message}</span><button onClick={() => setMessage("")} aria-label="Dismiss message"><X size={15} /></button></div>}
    </main>
  )
}

function SwapPanel({ fromToken, toToken, fromAmount, toAmount, quoteLoading, slippage, setFromAmount, setToAmount, setFromToken, setToToken, setSlippage, flip, execute, showSettings, setShowSettings, account }: any) {
  return <section className="mx-auto max-w-xl"><div className="mb-8 text-center"><div className="mb-3 inline-flex items-center gap-2 rounded-full border border-[#35d9ba]/20 bg-[#35d9ba]/10 px-3 py-1 text-xs font-semibold text-[#35d9ba]"><ArrowDownUp size={14} /> VVS routing</div><h1 className="text-4xl font-black tracking-tight">Swap tokens</h1><p className="mt-3 text-sm text-slate-400">Trade assets instantly on Cronos with transparent pricing.</p></div><div className="rounded-3xl border border-white/[0.1] bg-[#0d1a23] p-4 shadow-2xl shadow-black/20 sm:p-6"><div className="mb-3 flex items-center justify-between"><span className="text-sm font-semibold">Exchange</span><button onClick={() => setShowSettings(!showSettings)} className="rounded-lg p-2 text-slate-400 hover:bg-white/5 hover:text-white" aria-label="Swap settings"><Settings2 size={17} /></button></div>{showSettings && <div className="mb-4 rounded-xl border border-white/10 bg-white/[0.03] p-3"><label className="flex items-center justify-between text-xs text-slate-400">Slippage tolerance <select value={slippage} onChange={e => setSlippage(e.target.value)} className="rounded-lg border border-white/10 bg-[#13232d] px-2 py-1 text-white"><option value="0.1">0.1%</option><option value="0.5">0.5%</option><option value="1">1%</option></select></label></div>}<TokenBox label="You pay" token={fromToken} amount={fromAmount} onAmount={setFromAmount} onToken={setFromToken} /><button onClick={flip} className="relative z-10 mx-auto -my-3 flex h-10 w-10 items-center justify-center rounded-xl border-4 border-[#0d1a23] bg-[#1c3039] text-[#35d9ba] transition hover:bg-[#35d9ba] hover:text-[#071018]" aria-label="Switch tokens"><ArrowDown size={17} /></button><TokenBox label="You receive" token={toToken} amount={toAmount} onAmount={setToAmount} onToken={setToToken} readOnly loading={quoteLoading} /><div className="mt-4 flex items-center justify-between px-1 text-xs text-slate-500"><span>Rate {toAmount && fromAmount ? `${(Number(toAmount) / Number(fromAmount)).toFixed(4)} ${toToken.symbol}/${fromToken.symbol}` : "—"}</span><span>Slippage {slippage}%</span></div><button onClick={execute} className="mt-5 w-full rounded-xl bg-[#35d9ba] py-4 text-sm font-black text-[#071018] transition hover:bg-[#5ce8cd]">{account ? "Review swap" : "Connect wallet"}</button></div><p className="mt-4 text-center text-xs text-slate-500">By swapping, you agree to the transaction details shown in your wallet.</p></section>
}

function TokenBox({ label, token, amount, onAmount, onToken, readOnly, loading }: any) {
  return <div className="rounded-2xl border border-white/[0.08] bg-white/[0.035] p-4"><div className="mb-3 flex justify-between text-xs text-slate-500"><span>{label}</span><span>Balance —</span></div><div className="flex items-center gap-3"><input value={amount} onChange={e => onAmount(e.target.value)} readOnly={readOnly} inputMode="decimal" placeholder="0.00" className="min-w-0 flex-1 bg-transparent text-3xl font-bold tracking-tight outline-none placeholder:text-slate-600" /><button onClick={() => onToken(token)} className="flex shrink-0 items-center gap-2 rounded-xl border border-white/10 bg-white/[0.06] px-3 py-2 font-bold hover:bg-white/10"><TokenIcon token={token} size="sm" /><span>{token.symbol}</span><ChevronDown size={15} className="text-slate-500" /></button></div>{loading && <div className="mt-2 text-xs text-[#35d9ba]">Fetching best route...</div>}</div>
}
